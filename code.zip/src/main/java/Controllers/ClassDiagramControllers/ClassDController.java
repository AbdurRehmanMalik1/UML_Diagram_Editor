package Controllers.ClassDiagramControllers;

public interface ClassDController {
}
