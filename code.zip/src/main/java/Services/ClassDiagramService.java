package Services;

public class ClassDiagramService {
}
