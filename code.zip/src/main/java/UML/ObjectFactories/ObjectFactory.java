package UML.ObjectFactories;

import UML.Objects.UMLObject;

public interface ObjectFactory {
    public UMLObject create();
}
