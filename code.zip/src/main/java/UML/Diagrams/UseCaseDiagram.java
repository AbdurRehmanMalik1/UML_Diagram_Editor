package UML.Diagrams;

public class UseCaseDiagram  extends UMLDiagram{
    
}
