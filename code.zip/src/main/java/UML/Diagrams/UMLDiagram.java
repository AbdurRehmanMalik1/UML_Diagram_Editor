package UML.Diagrams;

import java.io.Serializable;

public abstract class UMLDiagram  implements Serializable {
    UMLDiagram(){

    }
}
