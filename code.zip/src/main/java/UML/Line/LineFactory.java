package UML.Line;

public class LineFactory {


}
