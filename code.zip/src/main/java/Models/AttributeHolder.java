package Models;

import java.util.List;

public interface AttributeHolder {
    public void addAttribute(String attribute);
    public List<String> getAttributes();
}
