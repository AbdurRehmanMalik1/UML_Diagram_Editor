package CodeGeneration;

import Models.Model;

public class CodeGenerator {
    public CodeGenerator(){

    }
    public void generateCode(Model model){

    }
}
