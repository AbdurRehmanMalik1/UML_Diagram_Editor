package CodeGeneration;

import Models.Model;

public class CodeGenerator {
    CodeGenerator(){

    }
    public void generateCode(Model model){

    }
}
